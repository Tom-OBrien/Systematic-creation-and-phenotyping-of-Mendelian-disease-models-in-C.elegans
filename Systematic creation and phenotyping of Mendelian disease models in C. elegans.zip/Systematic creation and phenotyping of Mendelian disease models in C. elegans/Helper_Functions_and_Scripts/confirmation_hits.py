#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 16 11:23:22 2023

@author: tobrien
"""
hits_full_name =[
                    'Vinblastine ', 
                    'Rizatriptan benzoate', 
                    'Olanzapine', 
                     'Atorvastatin calcium',
                    'Rofecoxib',
                    'Daunorubicin HCl',
                    'Norfloxacin',
                    'Ciprofloxacin',
                    'Carbenicillin disodium',
                    'Sulfadoxine',
                    'Ivabradine HCl',
                     'N2',
                     'unc-80_DMSO',
                    'Moxifloxacin',
                    'Ofloxacin',
                    'Idarubicin',
                    'Abitrexate',
                    'D-Cycloserine',
                    'Sulindac',
                    'Mesalamine',
                    'unc-80',
                    'Liranaftate'
                  ]


# hits_full_name =[
#                  'Rizatriptan benzoate', 
#                  'Rofecoxib',
#                  'Ivabradine HCl',
#                  'N2',
#                  'unc-80_DMSO',
#                  'D-Cycloserine',
#                  'Sulindac',
#                  'Mesalamine',
#                  ]

not_hits = [
            'Fenofibrate',
            'Iloperidone',
            'Mirtazapine',
            'Detomidine HCl',
            'Ziprasidone hydrochloride',
            'Clozapine',
            'Medetomidine HCl',
            'Azatadine dimaleate',
            'Amitriptyline HCl',
            'Loratadine',
            'Mitotane',
            ]
        